echo nais
ehh=$(sync; echo 3 > /proc/sys/vm/drop_caches)