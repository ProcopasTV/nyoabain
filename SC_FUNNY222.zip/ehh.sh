chmod +x *.sh
cp renew-trojan-prem.sh /usr/bin/renew-trojan-prem
cp renew-vless-prem.sh /usr/bin/renew-vless-prem
cp renew-vmess-prem.sh /usr/bin/renew-vmess-prem
cp renewsshprem.sh /usr/bin/renewsshprem