#!/bin/bash
rekt="/usr/bin"
chmod +x *.sh
cp add-trojan.sh $rekt/add-trojan
cp add-vless.sh $rekt/add-vless
cp add-vmess.sh $rekt/add-vmess
cp del-trojan.sh $rekt/del-trojan
cp del-vless.sh $rekt/del-vless
cp del-vmess.sh $rekt/del-vmess
cp renew-trojan.sh $rekt/renew-trojan
cp renew-vless.sh $rekt/rekt/renew-vless
cp renew-vmess.sh $rekt/renew-vmess
cp xp.sh $rekt/xp
cp clear-log.sh $rekt/clear-log
cp cek-service.sh $rekt/cek-service
cp cert.sh $rekt/cert
cp speedtest $rekt/speedtest
cp clear-ram.sh $rekt/clear-ram
cp menu-trojan.sh $rekt/menu-trojan
cp menu-vless.sh $rekt/menu-vless
cp menu-vmess.sh $rekt/menu-vmess
cp menu-ssh.sh $rekt/menu-ssh
cp cek-trojan.sh $rekt/cek-trojan
cp cek-vmess.sh $rekt/cek-vmess
cp cek-vless.sh $rekt/cek-vless
cp addssh.sh $rekt/addssh